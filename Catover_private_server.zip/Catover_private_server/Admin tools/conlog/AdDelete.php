<?php
include "connection.php";

// Check user login or not
if(!isset($_SESSION['uname'])){
    header('Location: index.php');
}

// logout
if(isset($_POST['but_logout'])){
    session_destroy();
    header('Location: index.php');
}
?>
<!DOCTYPE html>
 <html>
 <head>
 <title>AD</title>
 </head>
  <body style="background-color:powderblue;">
  <p style="font-size:160%; color:red;">Delete Accounts</p>
 <form method="post" action="con1.php"> 
Accounts ID: <input type="text" name="id">
<br>
<br>
 <input type="submit" value="Delete Accounts">
 </form>
<br>
<br>
<br>
<br>
 <p style="font-size:160%; color:red;">Delete Users</p>
<form method="post" action="con2.php"> 
User ID : <input type="text" name="id">
<br>
<br>
 <input type="submit" value="Delete User">
 </form>
 </body>
 </html>

