<?php
include "connection.php";

// Check user login or not
if(!isset($_SESSION['uname'])){
    header('Location: index.php');
}

// logout
if(isset($_POST['but_logout'])){
    session_destroy();
    header('Location: index.php');
}
?>
<?php 
$id = filter_input(INPUT_POST, 'id');

if (!empty($id))

{ 
include "connection.php";
 // Create connection 


$conn = new mysqli ($host, $dbusername, $dbpassword, $dbname2);

 if (mysqli_connect_error())
{ 

die('Connect Error ('. mysqli_connect_errno() .') ' . mysqli_connect_error()); 

} 

else

{ 

$sql = "DELETE FROM `users` WHERE `users`.`userID` = $id";

 if ($conn->query($sql))
{

 echo "sucessfully";

 }

 else
{

 echo "Error: ". $sql ." ". 
$conn->error; 
} 

$conn->close(); 
} 

} 

else

{ 

echo "dont empty or falled"; 

die();
 }

 ?>