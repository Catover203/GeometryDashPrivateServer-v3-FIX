<?php
// you need edit the $host, $dbuser, $dbppass, $dbname only :) mew :3//
//connection to database s1

$host = 'localhost';
$dbuser = ''; /* Username to connect to database */
$dbpass = ''; /* Password to connect to datsbase*/
$dbname = ''; /* Login database name */
$dbname2 = ''; /* GDPS database name */

//connection to database s2

$dbusername = $dbuser;
$dbpassword = $dbpass; 

//connection to databse s

session_start();
$user = $dbuser;
$password = $dbpass; 
$con = mysqli_connect($host, $user, $password,$dbname);

// Check connection
if (!$con) {
 die("Connection failed: " . mysqli_connect_error());
}
//gdps config
$serverName = $host;
$dbUsername = $dbuser;
$dbPassword = dbpass;
$dbName = $dbname2;
?>