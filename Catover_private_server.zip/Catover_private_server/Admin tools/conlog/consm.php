<?php
include "connection.php";

// Check user login or not
if(!isset($_SESSION['uname'])){
    header('Location: index.php');
}

// logout
if(isset($_POST['but_logout'])){
    session_destroy();
    header('Location: index.php');
}
?>
<?php 
$accid = filter_input(INPUT_POST, 'accid');
$modid = filter_input(INPUT_POST, 'modid');

if (!empty($accid))
if (!empty($modid))
{ 
include "connection.php"; 
 // Create connection 


$conn = new mysqli ($host, $dbusername, $dbpassword, $dbname2);

 if (mysqli_connect_error())
{ 

die('Connect Error ('. mysqli_connect_errno() .') ' . mysqli_connect_error()); 

} 

else

{ 

$sql = "INSERT INTO `roleassign`(`roleID`, `accountID`) VALUES ($modid,$accid)";

 if ($conn->query($sql))
{

 echo "sucessfully";

 }

 else
{

 echo "Error: ". $sql ." ". 
$conn->error; 
} 

$conn->close(); 
} 

} 

else

{ 

echo "empty or falled"; 

die();
 }

 ?>