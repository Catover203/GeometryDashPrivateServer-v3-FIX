<?php
include 'catconnect.php';
// Check connection
if (!$con) {
 die("Connection failed: " . mysqli_connect_error());
}
// Check user login or not
if(!isset($_SESSION['uname'])){
    header('Location: index.login.php');
}

// logout
if(isset($_POST['but_logout'])){
    session_destroy();
    header('Location: index.login.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
 <title>
ADMIN TOOLS
</title>
</head>
<body style="background-color:powderblue;">
<h1>Homepage</h1>
<form method='post' action="">
<input type="submit" value="Logout" name="but_logout">
</form>
leaderboard ban <a href="http://socalcat.ueuo.com/database/dashboard/tools/leaderboardsBan.php">here</a>

<br>
<br>

leaderboard Unban <a href="http://socalcat.ueuo.com/database/dashboard/tools/leaderboardsUnban.php">here</a>

<br>
<br>

Create package <a href="http://socalcat.ueuo.com/database/dashboard/tools/mapPackAdd.php">here</a>

<br>
<br>

Delete Account <a href="AdDelete.php">here</a>

<br>
<br>

all user <a href="alluser.php">here</a>
<br>
<br>
set mod <a href="sm.php">here</a>
</body>
</html>