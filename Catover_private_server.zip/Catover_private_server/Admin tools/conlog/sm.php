<?php
include "connection.php";

// Check user login or not
if(!isset($_SESSION['uname'])){
    header('Location: index.php');
}

// logout
if(isset($_POST['but_logout'])){
    session_destroy();
    header('Location: index.php');
}
?>
<!DOCTYPE html>
 <html>
 <head>
 <title>AD</title>
 </head>
 <body style="background-color:powderblue;">
<p style="font-size:160%; color:red;">Set Mod</p>
 <form method="post" action="consm.php"> 
Mod ID: <input type="text" name="modid">
<br>
Accounts ID: <input type="text" name="accid">
<br>
 <input type="submit" value="set mod">
 </form>
<br>
<br>
<br>
<br>
<p style="font-size:160%; color:red;">Delete mod</p>
 <form method="post" action="condm.php"> 
Assign ID: <input type="text" name="mid">
<br>
 <input type="submit" value="delete mod">
 </form>
 </body>
 </html>
<br>
<br>
<br>
<br>
<p style="font-size:160%; color:red;">Mod board</p>
<?php
include 'role123.php'
?>