<?php
include 'catconnect.php';
// Check connection
if (!$con) {
 die("Connection failed: " . mysqli_connect_error());
}
// Check user login or not
if(!isset($_SESSION['uname'])){
    header('Location: index.login.php');
}

// logout
if(isset($_POST['but_logout'])){
    session_destroy();
    header('Location: index.login.php');
}
?>
<!doctype html>
<html>
    <head></head>
    <body>
        <h1>Homepage</h1>
        <form method='post' action="">
            <input type="submit" value="Logout" name="but_logout">
        </form>
    </body>
</html>
<?php
header('Location: conlog/index.php');
?>